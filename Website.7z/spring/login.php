  <?php
$servername = "localhost";
$username = "1057414";
$password = "spring";
$dbname = "1057414";

	// Create connection
	$con = mysqli_connect($servername, $username, $password, $dbname);

	// Check connection
	if (mysqli_connect_error()) {
		echo "Connection failed: " . mysqli_connect_error();
	}
	 
	$user  = $_GET['user']; //Unsafe, but for demo purposes only
	$pass  = $_GET['pass'];

	$sql = "SELECT id_login FROM login WHERE username='".$user."' AND password='".$pass."'";

	$result = mysqli_query($con,$sql);

	if(mysqli_num_rows($result) > 0) 
	{ 
		while($r = mysqli_fetch_assoc($result)) 
		{
			$rows[] = $r;
		}   
		echo json_encode(array("result"=>$rows));
	}
	else 
	{
		$fail = '-1';
		$rows[] = array('id_login'=>$fail);
		echo json_encode(array("result"=>$rows));
	}
mysqli_close($con);
?> 
