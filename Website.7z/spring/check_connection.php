 <?php
$servername = "localhost";
$username = "1057414";
$password = "spring";
$dbname = "1057414";

	// Create connection
	$con = mysqli_connect($servername, $username, $password, $dbname);

	// Check connection
	if (mysqli_connect_error()) {
		$fail = 'fail';
		$rows[] = array('db_conn'=>$fail);
		echo json_encode(array("result"=>$rows));
	}
	else {
		$success = 'success';
		$rows[] = array('db_conn'=>$success);
		echo json_encode(array("result"=>$rows));
	}
	mysqli_close($con);
?> 
