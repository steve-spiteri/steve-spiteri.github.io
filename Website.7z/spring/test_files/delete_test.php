 <?php
$servername = "localhost";
$username = "1057414";
$password = "spring";
$dbname = "1057414";

// Create connection
$con = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (mysqli_connect_error()) {
    echo "Connection failed: " . mysqli_connect_error();
}
echo "Connected successfully";

$sql = "DELETE FROM data WHERE id_data = 6";
if (mysqli_query($con,$sql)) {
      echo "Values have been deleted successfully";
   }
   else{
		echo "Delete failed";
   }
   
mysqli_close($con);
?> 