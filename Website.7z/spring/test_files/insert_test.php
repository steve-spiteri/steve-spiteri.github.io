 <?php
$servername = "localhost";
$username = "1057414";
$password = "spring";
$dbname = "1057414";
   $con = mysqli_connect($servername, $username, $password, $dbname);
   
   /*$id_login = $_GET['id_login'];
   $power = $_GET['power'];
   $temperature = $_GET['temperature'];
   $light = $_GET['light'];
   $bar_pressure = $_GET['bar_pressure'];
   $humidity = $_GET['humidity'];
   $date = $_GET['date'];*/
   
   $sql="INSERT INTO data (id_login, power, temperature, light, bar_pressure, humidity, date) VALUES (2, 7.8, 21, 20500, 102.8, 75, STR_TO_DATE( '24/08/2014 6:42:21', '%d/%m/%Y %H:%i:%s'))";
   //$sql="INSERT INTO data (id_login, power, temperature, light, bar_pressure, humidity, date) VALUES ($id_login, $power, $temperature, $light, $bar_pressure, $humidity, STR_TO_DATE( '$date', '%d/%m/%Y %H:%i:%s'))";
   if (mysqli_query($con,$sql)) {
      $output="Success";
   }
   else{
		$output="Fail";
   }
   print (json_encode($output));
?>