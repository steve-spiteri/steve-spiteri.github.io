 <?php
$servername = "localhost";
$username = "1057414";
$password = "spring";
$dbname = "1057414";

// Create connection
$con = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (mysqli_connect_error()) {
    echo "Connection failed: " . mysqli_connect_error();
}
//echo "Connected successfully";
/*
$sql = "SELECT * FROM login";
$result = mysqli_query($con,$sql);
$count = mysqli_num_rows($result);
if ($count > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
		echo "<br>";
        echo "<br>" . "Login ID: " . $row["id_login"]. "<br>" . "Username: " . $row["username"]. "<br>" . "Password " .$row["password"]. "<br>";
    }
} else {
    echo "0 results";
}*/

 //if($_SERVER['REQUEST_METHOD']=='GET'){
 
 //$id  = $_GET['id'];

//$sql = "SELECT id_data, id_login, power, temperature, light, bar_pressure, humidity, TIME(date) as \"time\", DATE(date) as \"date\" FROM data WHERE id_data='".$id."'";

$sql = "SELECT id_data, id_login, power, temperature, light, bar_pressure, humidity, TIME(date) as \"time\", DATE(date) as \"date\" FROM data";
$result = mysqli_query($con,$sql);

$rows = array();
    while($r = mysqli_fetch_assoc($result)) {
        $rows[] = $r;
    }   
	echo json_encode(array("result"=>$rows));
/* $res = mysqli_fetch_array($result);
$r = array();
 array_push($r,array
	 (
	 "id_data"=>$res['id_data'],
	 "power"=>$res['power'],
	 )
 );
 
 echo json_encode(array("result"=>$r));
 */
mysqli_close($con);
?> 
