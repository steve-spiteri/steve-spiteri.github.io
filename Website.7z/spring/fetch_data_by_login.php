 <?php
$servername = "localhost";
$username = "1057414";
$password = "spring";
$dbname = "1057414";

// Create connection
$con = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (mysqli_connect_error()) {
    echo "Connection failed: " . mysqli_connect_error();
}
 
$id  = $_GET['id'];

$sql = "SELECT id_data, id_login, power, temperature, light, bar_pressure, humidity, TIME(date) as \"time\", DATE(date) as \"date\" FROM data WHERE id_login='".$id."'";

$result = mysqli_query($con,$sql);

$rows = array();
    while($r = mysqli_fetch_assoc($result)) {
        $rows[] = $r;
    }   
	echo json_encode(array("result"=>$rows));
mysqli_close($con);
?> 
