<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>SPrINg - Solar Panel Interactive Display</title>
    <link rel="icon" type="image/png" href="favicon-32x32.png" sizes="32x32" />
    <link rel="stylesheet" type="text/css" href="style.css"
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
</head>
<body>

<?php
$id_login = "";
session_start();
$id_login = $_SESSION["id_login"];
//$url = "http://springdb.eu5.org//spring/fetch_data_by_login.php?id=" . $id_login;
$url = "http://springdb.eu5.org//spring/fetch_data_by_login.php?id=99";
$lines_string=file_get_contents($url);
$jObj = json_decode($lines_string, true);

echo "The length of the array is " . count($jObj['result']) . "<br>";

for($x = 0; $x < count($jObj['result']); $x++) {
    $power[$x] = $jObj['result'][$x]['power'];
	$temperature[$x] = $jObj['result'][$x]['temperature'];
	$light[$x] = $jObj['result'][$x]['light'];
	$bar_pressure[$x] = $jObj['result'][$x]['bar_pressure'];
	$humidity[$x] = $jObj['result'][$x]['humidity'];
	$date[$x] = $jObj['result'][$x]['date'];
	$time[$x] = $jObj['result'][$x]['time'];
}

$_SESSION["power"] = $power;
$_SESSION["temperature"] = $temperature;
$_SESSION["light"] = $light;
$_SESSION["bar_pressure"] = $bar_pressure;
$_SESSION["humidity"] = $humidity;
$_SESSION["date"] = $date;
$_SESSION["time"] = $time;

$_SESSION["humidityLast"] = 0;

?>

<div id="iframediv">
<iframe id="iframe" name="iframe" src="humidity.php" scrolling="no" frameborder="0">
  <p>Your browser does not support iframes.</p>
</iframe>
</div>

</body>
</html> 