<!DOCTYPE html>
<html>
	<?php
                session_start();
		$username = $password = $id_login = $error = "";
		
		$username = test_input($_POST["username"]);
		$password = test_input($_POST["password"]);
		
		$url = "http://springdb.eu5.org/spring/login.php?user=" . $username . "&pass=" . $password;
		$lines_string=file_get_contents($url);
		$jObj = json_decode($lines_string, true);
		$id_login = $jObj['result'][0]['id_login'];
		
		function test_input($data) {
		  $data = trim($data);
		  $data = stripslashes($data);
		  $data = htmlspecialchars($data);
		  return $data;
		}
		
		if ($id_login == "-1"){
			$error = "Invalid Username/Password";
		} else {
                        $_SESSION["id_login"]=$id_login;
			//header("Location: http://springdb.eu5.org/data-1.php?id_login=" . $id_login);
                        header("Location: http://springdb.eu5.org/data.php");
			exit;
		}
    ?>

	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title>SPrINg - Solar Panel Interactive Display</title>
        <link rel="icon" type="image/png" href="favicon-32x32.png" sizes="32x32" />
        <link rel="stylesheet" type="text/css" href="style.css">
        <link href="https://fonts.googleapis.com/css?family=Droid+Sans" rel="stylesheet"> 
	</head>
    
    <body>
        <div id="mid">
                    <img src="images/logo.png" width="570" height="310" alt=""/><br>
                    <br>
                    <?php
					echo "<span style='color:red;'><b>" . $error . "</b></span><br>";
					?>
                    <br>
                    <div id="login">
                        <span style="font-size: xx-large">Login</span>
        				<hr>
                        <br>
                        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                            Username<br>
                            <input type="text" name="username" style="width: 740px;"><br>
                            <br>
                            Password<br>
                            <input type="password" name="password" style="width: 740px;"<br>
                            <br>
                            <hr>
                            <div id="signin">
                                <input name="submit" type="submit" class="submit" value="SIGN IN">
                            </div>
                        </form>
                    </div>
        </div>
    </body>
</html> 	