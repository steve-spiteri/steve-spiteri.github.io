<html>
<head>
	<script src='Chart.min.js'></script>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link href="https://fonts.googleapis.com/css?family=Droid+Sans" rel="stylesheet"> 
</style>
</head>

<body>

<?php
session_start();
$humidity = $_SESSION["humidity"];
$date = $_SESSION["date"];
$time = $_SESSION["time"];
echo $_SESSION["humidityLast"];

?>

<!-- title -->
<div id="titlewrapper"></div>
<!-- line chart canvas element -->
<canvas id="humidityCanvas"></canvas>

<script>
var control = 1;
while(control==1)
{
	var rn = Math.floor((Math.random()*2)+1);
	document.write(rn);
	if(rn!=<?php echo $_SESSION["humidityLast"]; ?>)
	{
		control=0;
	}
}

if(rn==1)
{
	sixMin();
	document.write("this is one");
	<?php $_SESSION["humidityLast"] = 1; ?>

}
else if (rn==2)
{
	oneHour();
	document.write("this is two");
	<?php $_SESSION["humidityLast"] = 2; ?>
}

function sixMin() {
	document.getElementById("titlewrapper").innerHTML = "Humidity from the last 6 minutes";
	// line chart data
	var humidityData = {
			//x-axis
			labels: [
			<?php
			for($x = 0;$x<=24;$x++) {
				$day = count($time) - 24 + $x;
				echo '"'.$time[$day].'"';
				if($x!=count($time)) {
					echo ",";
				}
			}
			?>],
			datasets : [
			{
					fill: false,
					fillColor : "rgba(150, 224, 222, 0.5)",
					strokeColor : "#76CDCE",
					pointColor : "#fff",
					pointStrokeColor : "#000",
					data : [
					<?php
					//y-axis
					for($x = 0;$x<=24;$x++) {
						$day = count($humidity) - 24 + $x;
						echo $humidity[$day];
						if($x!=count($humidity)) {
							echo ",";
						}
					}
					?>]
				}
			]
		};
	var humidityGraph = document.getElementById('humidityCanvas').getContext('2d');
	humidityCanvas.width  = window.innerWidth;
	humidityCanvas.height = window.innerHeight*.8;
	humidityCanvas.fillStyle='#fff';
	// draw line chart
	new Chart(humidityGraph).Line(humidityData);
}

function oneHour() {
	document.getElementById("titlewrapper").innerHTML = "Humidity from the last hour";
	// line chart data
	var humidityData = {
			//x-axis
			labels: [
			<?php
			for($x = 0;$x<=24;$x++) {
				$day = count($time) - 24 + $x;
				echo '"'.$time[$day].'"';
				if($x!=count($time)) {
					echo ",";
				}
			}
			?>],
			datasets : [
			{
					fill: false,
					fillColor : "rgba(150, 224, 222, 0.5)",
					strokeColor : "#76CDCE",
					pointColor : "#fff",
					pointStrokeColor : "#000",
					data : [
					<?php
					//y-axis
					for($i = 0, $k = count($humidity)-240;$i<24;$i++,$k+=10) {
						for($x=0;$x<10;$x++)
						{
							$num += $humidity[$k+$x];
						}
						echo $num/10;
						if($i!=count($humidity)) {
							$num = 0.0;
							echo ",";
						}
					}
					?>]
				}
			]
		};
	var humidityGraph = document.getElementById('humidityCanvas').getContext('2d');
	humidityCanvas.width  = window.innerWidth;
	humidityCanvas.height = window.innerHeight*.8;
	humidityCanvas.fillStyle='#fff';
	// draw line chart
	new Chart(humidityGraph).Line(humidityData);
}
</script>

</body>
</html>
