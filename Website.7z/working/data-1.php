<!DOCTYPE html>
<html>
<body>

<?php
$id_login = "";
session_start();
$id_login = $_SESSION["id_login"];
//$id_login = htmlspecialchars($_GET["id_login"]);
$url = "http://springdb.eu5.org//spring/fetch_data_by_login.php?id=" . $id_login;
$lines_string=file_get_contents($url);
$jObj = json_decode($lines_string, true);

echo "The length of the array is " . count($jObj['result']) . "<br>";

for($x = 0; $x < count($jObj['result']); $x++) {
    $power[$x] = $jObj['result'][$x]['power'];
	$temperature[$x] = $jObj['result'][$x]['temperature'];
	$light[$x] = $jObj['result'][$x]['light'];
	$bar_pressure[$x] = $jObj['result'][$x]['bar_pressure'];
	$humidity[$x] = $jObj['result'][$x]['humidity'];
	$date[$x] = $jObj['result'][$x]['date'];
}
?>
<table width="100%" border="1">
  <tr>
    <th scope="col">Power</th>
    <th scope="col">Temperature</th>
    <th scope="col">Light</th>
    <th scope="col">Barometric Pressure</th>
    <th scope="col">Humidity</th>
    <th scope="col">Date</th>
  </tr>
  <?php
  for($x = 0; $x < count($jObj['result']); $x++) {
	echo "<tr>";
	echo "<td>" . $power[$x] . " V</td>";
	echo "<td>" . $temperature[$x] . " F</td>";
	echo "<td>" . $light[$x] . " Lux</td>";
	echo "<td>" . $bar_pressure[$x] . " kPa</td>";
	echo "<td>" . $humidity[$x] . " %</td>";
	echo "<td>" . $date[$x] . "</td>";
	echo "</tr>";
  }
  ?>
</table>

</body>
</html> 