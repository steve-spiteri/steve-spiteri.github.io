 <?php
$servername = "localhost";
$username = "1057414";
$password = "spring";
$dbname = "1057414";

// Create connection
$con = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (mysqli_connect_error()) {
    echo "Connection failed: " . mysqli_connect_error();
}
echo "Connected successfully";

$sql = "SELECT * FROM login";
$result = mysqli_query($con,$sql);
$count = mysqli_num_rows($result);
if ($count > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
		echo "<br>";
        echo "<br>" . "Login ID: " . $row["id_login"]. "<br>" . "Username: " . $row["username"]. "<br>" . "Password " .$row["password"]. "<br>";
    }
} else {
    echo "0 results";
}

$sql = "SELECT id_data, id_login, power, temperature, light, bar_pressure, humidity, TIME(date) as \"time\", DATE(date) as \"date\" FROM data";
$result = mysqli_query($con,$sql);
 
$count = mysqli_num_rows($result);
if ($count > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
		echo "<br>";
        echo "<br>" . "Data ID: " . $row["id_data"]."<br>";
		echo "Login ID: " . $row["id_login"]. "<br>";
		echo "Power: " .$row["power"]. "kW" ."<br>";
		echo "Temp:  " .$row["temperature"]. " Degrees Celcius" ."<br>";
		echo "Light: " .$row["light"]. " Lux"."<br>";
		echo "Barometric:  " .$row["bar_pressure"]. "kPa" . "<br>";
		echo "Humidity: " .$row["humidity"]. "%" ."<br>";
		echo "Time: " .$row["time"]. "<br>";
		echo "Date: " .$row["date"]. "<br>";
    }
} else {
    echo "0 results";
}

mysqli_close($con);
?> 